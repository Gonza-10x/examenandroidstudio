package com.example.collageapp.model

import android.graphics.Bitmap
import android.net.Uri

/**
 * Foto del collage. Es inmutable: cada cambio (filtro, rotación, brillo) genera una copia
 * con [copy], de modo que [original] nunca se modifica y siempre se puede restaurar.
 */
data class CollageImage(
    val id: Long,
    val uri: Uri,
    val original: Bitmap,
    val current: Bitmap,
    val rotation: Float = 0f,
    val brightness: Float = 0f,
    val filter: FilterType = FilterType.NONE
) {
    enum class FilterType { NONE, GRAYSCALE, SEPIA }
}
