package com.example.collageapp.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import com.example.collageapp.model.CollageImage.FilterType
import kotlin.math.min

object ImageUtils {

    private const val TAG = "ImageUtils"
    private const val CELL_COLOR = 0xFF2A2A2A.toInt()

    // ---------- Carga ----------

    /** Carga la imagen reducida (para no agotar memoria) y corrige su orientación EXIF. */
    fun loadBitmapFromUri(context: Context, uri: Uri, maxSize: Int = 1024): Bitmap? {
        return try {
            val resolver = context.contentResolver

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while (bounds.outWidth / sample > maxSize || bounds.outHeight / sample > maxSize) {
                sample *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val decoded = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            } ?: return null

            applyExifOrientation(decoded, readExifOrientation(context, uri))
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo cargar $uri", e)
            null
        } catch (e: OutOfMemoryError) {
            Log.e(TAG, "Memoria insuficiente al cargar $uri", e)
            null
        }
    }

    private fun readExifOrientation(context: Context, uri: Uri): Int = try {
        context.contentResolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        } ?: ExifInterface.ORIENTATION_NORMAL
    } catch (e: Exception) {
        ExifInterface.ORIENTATION_NORMAL
    }

    private fun applyExifOrientation(src: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.postRotate(90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.postRotate(-90f); matrix.postScale(-1f, 1f) }
            else -> return src
        }
        val result = Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
        if (result !== src) src.recycle()
        return result
    }

    // ---------- Filtros y ajustes ----------

    fun applyGrayscale(src: Bitmap): Bitmap =
        drawWithMatrix(src, ColorMatrix().apply { setSaturation(0f) })

    fun applySepia(src: Bitmap): Bitmap {
        val matrix = ColorMatrix().apply {
            setSaturation(0f)
            postConcat(ColorMatrix(floatArrayOf(
                1.1f, 0f, 0f, 0f, 30f,
                0f, 0.95f, 0f, 0f, 20f,
                0f, 0f, 0.8f, 0f, 10f,
                0f, 0f, 0f, 1f, 0f
            )))
        }
        return drawWithMatrix(src, matrix)
    }

    fun applyBrightness(src: Bitmap, brightness: Float): Bitmap {
        if (brightness == 0f) return src
        val value = (brightness * 255f).coerceIn(-255f, 255f)
        return drawWithMatrix(src, ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, value,
            0f, 1f, 0f, 0f, value,
            0f, 0f, 1f, 0f, value,
            0f, 0f, 0f, 1f, 0f
        )))
    }

    fun rotateBitmap(src: Bitmap, degrees: Float): Bitmap {
        if (degrees % 360f == 0f) return src
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    /** Siempre parte de [original], que no se modifica nunca. */
    fun processImage(
        original: Bitmap,
        filter: FilterType,
        rotation: Float,
        brightness: Float
    ): Bitmap {
        var bmp = original
        bmp = when (filter) {
            FilterType.GRAYSCALE -> applyGrayscale(bmp)
            FilterType.SEPIA -> applySepia(bmp)
            FilterType.NONE -> bmp
        }
        bmp = applyBrightness(bmp, brightness)
        bmp = rotateBitmap(bmp, rotation)
        return bmp
    }

    private fun drawWithMatrix(src: Bitmap, matrix: ColorMatrix): Bitmap {
        val result = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(matrix) }
        Canvas(result).drawBitmap(src, 0f, 0f, paint)
        return result
    }

    // ---------- Collage final ----------

    /**
     * Dibuja las fotos en una cuadrícula de [columns] columnas, igual que en pantalla:
     * celdas cuadradas con la foto centrada y sin deformar.
     */
    fun buildCollageBitmap(
        images: List<Bitmap>,
        columns: Int,
        cellSize: Int = 500,
        gap: Int = 6
    ): Bitmap {
        require(images.isNotEmpty()) { "El collage está vacío" }
        val cols = columns.coerceAtLeast(1)
        val rows = (images.size + cols - 1) / cols
        val result = Bitmap.createBitmap(cols * cellSize, rows * cellSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)

        val cellPaint = Paint().apply { color = CELL_COLOR }
        val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        val size = (cellSize - 2 * gap).toFloat()

        images.forEachIndexed { i, bmp ->
            val left = (i % cols) * cellSize + gap.toFloat()
            val top = (i / cols) * cellSize + gap.toFloat()
            canvas.drawRect(left, top, left + size, top + size, cellPaint)

            val scale = min(size / bmp.width, size / bmp.height)
            val w = bmp.width * scale
            val h = bmp.height * scale
            val dl = left + (size - w) / 2f
            val dt = top + (size - h) / 2f
            canvas.drawBitmap(bmp, null, RectF(dl, dt, dl + w, dt + h), bitmapPaint)
        }
        return result
    }
}
