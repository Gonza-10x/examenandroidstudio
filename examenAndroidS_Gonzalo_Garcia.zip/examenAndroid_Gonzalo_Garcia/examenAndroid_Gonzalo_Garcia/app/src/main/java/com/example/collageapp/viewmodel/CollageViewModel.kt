package com.example.collageapp.viewmodel

import android.app.Application
import android.net.Uri
import androidx.annotation.StringRes
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.collageapp.R
import com.example.collageapp.model.CollageImage
import com.example.collageapp.model.CollageImage.FilterType
import com.example.collageapp.utils.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class CollageState(
    val images: List<CollageImage> = emptyList(),
    val selectedId: Long? = null
) {
    val selected: CollageImage? get() = images.firstOrNull { it.id == selectedId }
}

/**
 * Guarda el estado del collage. Sobrevive a giros de pantalla y otros cambios de
 * configuración, por lo que las fotos y sus ediciones no se pierden.
 */
class CollageViewModel(application: Application) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(CollageState())
    val state: StateFlow<CollageState> = _state.asStateFlow()

    private val _messages = Channel<Int>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    private var nextId = 0L
    private val processing = mutableMapOf<Long, Job>()

    private fun sendMessage(@StringRes res: Int) {
        _messages.trySend(res)
    }

    // ---------- Añadir ----------

    fun addImages(uris: List<Uri>) {
        if (uris.isEmpty()) {
            sendMessage(R.string.msg_nada_elegido)
            return
        }
        val known = _state.value.images.map { it.uri }.toSet()
        val nuevas = uris.distinct().filter { it !in known }
        if (nuevas.size < uris.size) sendMessage(R.string.msg_imagen_duplicada)
        if (nuevas.isEmpty()) return

        viewModelScope.launch {
            val app = getApplication<Application>()
            val cargadas = withContext(Dispatchers.IO) {
                nuevas.mapNotNull { uri ->
                    ImageUtils.loadBitmapFromUri(app, uri)?.let { bmp -> uri to bmp }
                }
            }
            if (cargadas.size < nuevas.size) sendMessage(R.string.msg_error_carga)

            _state.update { s ->
                // Se vuelve a comprobar por si se pulsó "Añadir" varias veces seguidas
                val presentes = s.images.map { it.uri }.toSet()
                val anadir = cargadas
                    .filter { (uri, _) -> uri !in presentes }
                    .map { (uri, bmp) ->
                        CollageImage(id = nextId++, uri = uri, original = bmp, current = bmp)
                    }
                s.copy(images = s.images + anadir)
            }
        }
    }

    // ---------- Selección y borrado ----------

    fun toggleSelection(id: Long) {
        _state.update { it.copy(selectedId = if (it.selectedId == id) null else id) }
    }

    fun removeSelected() {
        val id = _state.value.selectedId
        if (id == null) {
            sendMessage(R.string.msg_sin_seleccion)
            return
        }
        processing.remove(id)?.cancel()
        _state.update { s -> s.copy(images = s.images.filterNot { it.id == id }, selectedId = null) }
        sendMessage(R.string.msg_eliminada)
    }

    fun clearAll() {
        processing.values.forEach { it.cancel() }
        processing.clear()
        _state.value = CollageState()
        sendMessage(R.string.msg_limpio)
    }

    // ---------- Edición de la foto seleccionada ----------

    fun applyFilter(filter: FilterType) = editSelected { it.copy(filter = filter) }

    fun rotateSelected() = editSelected { it.copy(rotation = (it.rotation + 90f) % 360f) }

    fun restoreSelected() = editSelected {
        it.copy(filter = FilterType.NONE, rotation = 0f, brightness = 0f)
    }

    fun setBrightness(value: Float) =
        editSelected(warnIfNone = false) { it.copy(brightness = value) }

    private fun editSelected(warnIfNone: Boolean = true, transform: (CollageImage) -> CollageImage) {
        val id = _state.value.selectedId
        if (id == null) {
            if (warnIfNone) sendMessage(R.string.msg_sin_seleccion)
            return
        }
        _state.update { s ->
            s.copy(images = s.images.map { if (it.id == id) transform(it) else it })
        }
        reprocess(id)
    }

    /** Recalcula la imagen visible desde el original. Cancela el cálculo anterior de esa foto. */
    private fun reprocess(id: Long) {
        val item = _state.value.images.firstOrNull { it.id == id } ?: return
        processing[id]?.cancel()
        processing[id] = viewModelScope.launch {
            val bmp = withContext(Dispatchers.Default) {
                ImageUtils.processImage(item.original, item.filter, item.rotation, item.brightness)
            }
            _state.update { s ->
                s.copy(images = s.images.map { cur ->
                    val vigente = cur.id == id && cur.filter == item.filter &&
                        cur.rotation == item.rotation && cur.brightness == item.brightness
                    if (vigente) cur.copy(current = bmp) else cur
                })
            }
        }
    }
}
