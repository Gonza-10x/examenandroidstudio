package com.example.collageapp

import android.content.ClipData
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.collageapp.adapter.CollageAdapter
import com.example.collageapp.model.CollageImage
import com.example.collageapp.utils.ImageUtils
import com.example.collageapp.viewmodel.CollageState
import com.example.collageapp.viewmodel.CollageViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private val viewModel: CollageViewModel by viewModels()

    private lateinit var recycler: RecyclerView
    private lateinit var tvVacio: TextView
    private lateinit var seekBrillo: SeekBar
    private lateinit var btnCompartir: Button
    private lateinit var adapter: CollageAdapter

    private var updatingSeek = false
    private var spanCount = 2

    private val pickMultiple =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(MAX_FOTOS)) { uris ->
            viewModel.addImages(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupInsets()

        recycler = findViewById(R.id.recyclerCollage)
        tvVacio = findViewById(R.id.tvVacio)
        seekBrillo = findViewById(R.id.seekBrillo)
        btnCompartir = findViewById(R.id.btnCompartir)

        spanCount = calcularColumnas()
        adapter = CollageAdapter { id -> viewModel.toggleSelection(id) }
        recycler.layoutManager = GridLayoutManager(this, spanCount)
        recycler.adapter = adapter

        setupButtons()
        setupSeekBar()
        observeViewModel()
    }

    /** Evita que el contenido quede bajo las barras del sistema (edge-to-edge en Android 15+). */
    private fun setupInsets() {
        val root = findViewById<View>(R.id.root)
        val left = root.paddingLeft
        val top = root.paddingTop
        val right = root.paddingRight
        val bottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.updatePadding(
                left = left + bars.left,
                top = top + bars.top,
                right = right + bars.right,
                bottom = bottom + bars.bottom
            )
            insets
        }
        WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars = false
    }

    /** Número de columnas según el ancho disponible para la cuadrícula. */
    private fun calcularColumnas(): Int {
        val config = resources.configuration
        val ancho = config.screenWidthDp.toFloat()
        val anchoGrid = if (config.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
            ancho * 0.6f else ancho
        return (anchoGrid / 150f).toInt().coerceIn(2, 5)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { viewModel.state.collect { render(it) } }
                launch { viewModel.messages.collect { toast(getString(it)) } }
            }
        }
    }

    private fun render(state: CollageState) {
        adapter.submit(state.images, state.selectedId)

        val vacio = state.images.isEmpty()
        tvVacio.visibility = if (vacio) View.VISIBLE else View.GONE
        recycler.visibility = if (vacio) View.INVISIBLE else View.VISIBLE

        // El deslizador refleja el brillo de la foto seleccionada (o el valor neutro)
        val objetivo = state.selected
            ?.let { ((it.brightness + 1f) * SEEK_NEUTRO).roundToInt() } ?: SEEK_NEUTRO
        if (!seekBrillo.isPressed && seekBrillo.progress != objetivo) {
            updatingSeek = true
            seekBrillo.progress = objetivo
            updatingSeek = false
        }
    }

    private fun setupButtons() {
        findViewById<Button>(R.id.btnAnadir).setOnClickListener { anadirFotos() }

        findViewById<Button>(R.id.btnEliminar).setOnClickListener { viewModel.removeSelected() }

        findViewById<Button>(R.id.btnEliminarTodas).setOnClickListener {
            if (viewModel.state.value.images.isEmpty()) {
                toast(getString(R.string.msg_collage_vacio))
                return@setOnClickListener
            }
            AlertDialog.Builder(this)
                .setMessage(R.string.msg_confirmar_vaciar)
                .setPositiveButton(R.string.msg_si) { _, _ -> viewModel.clearAll() }
                .setNegativeButton(R.string.msg_cancelar, null)
                .show()
        }

        findViewById<Button>(R.id.btnBlancoNegro).setOnClickListener {
            viewModel.applyFilter(CollageImage.FilterType.GRAYSCALE)
        }
        findViewById<Button>(R.id.btnSepia).setOnClickListener {
            viewModel.applyFilter(CollageImage.FilterType.SEPIA)
        }
        findViewById<Button>(R.id.btnRestaurar).setOnClickListener { viewModel.restoreSelected() }
        findViewById<Button>(R.id.btnRotar).setOnClickListener { viewModel.rotateSelected() }
        btnCompartir.setOnClickListener { compartirCollage() }
    }

    // ---------- Origen de las fotos ----------

    /** Si hay fotos "foto_..." en res/drawable las ofrece; si no, abre la galería. */
    private fun anadirFotos() {
        val fotos = fotosDeRes()
        if (fotos.isEmpty()) abrirGaleria() else mostrarFotosRes(fotos)
    }

    private fun abrirGaleria() {
        pickMultiple.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
    }

    /** Fotos de res/drawable cuyo nombre empieza por "foto_" (p. ej. foto_1.jpg). */
    private fun fotosDeRes(): List<Pair<String, Uri>> =
        R.drawable::class.java.fields
            .map { it.name }
            .filter { it.startsWith(PREFIJO_FOTO) }
            .sorted()
            .map { it to Uri.parse("android.resource://$packageName/drawable/$it") }

    private fun mostrarFotosRes(fotos: List<Pair<String, Uri>>) {
        val marcadas = BooleanArray(fotos.size)
        AlertDialog.Builder(this)
            .setTitle(R.string.origen_res)
            .setMultiChoiceItems(fotos.map { it.first }.toTypedArray(), marcadas) { _, i, checked ->
                marcadas[i] = checked
            }
            .setPositiveButton(R.string.btn_anadir_corto) { _, _ ->
                viewModel.addImages(fotos.filterIndexed { i, _ -> marcadas[i] }.map { it.second })
            }
            .setNegativeButton(R.string.msg_cancelar, null)
            .show()
    }

    private fun setupSeekBar() {
        seekBrillo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser || updatingSeek) return
                viewModel.setBrightness((progress - SEEK_NEUTRO) / SEEK_NEUTRO.toFloat())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                if (viewModel.state.value.selected == null) toast(getString(R.string.msg_sin_seleccion))
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                if (viewModel.state.value.selected == null) {
                    updatingSeek = true
                    sb?.progress = SEEK_NEUTRO
                    updatingSeek = false
                }
            }
        })
    }

    // ---------- Compartir ----------

    private fun compartirCollage() {
        val bitmaps = viewModel.state.value.images.map { it.current }
        if (bitmaps.isEmpty()) {
            toast(getString(R.string.msg_collage_vacio))
            return
        }
        btnCompartir.isEnabled = false
        lifecycleScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) {
                    val collage = ImageUtils.buildCollageBitmap(bitmaps, spanCount)
                    try {
                        saveBitmapToCache(collage)
                    } finally {
                        collage.recycle()
                    }
                }
                if (uri == null) {
                    toast(getString(R.string.msg_compartir_error))
                    return@launch
                }
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    clipData = ClipData.newRawUri(null, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(intent, getString(R.string.msg_compartir_titulo)))
            } catch (e: CancellationException) {
                throw e
            } catch (e: OutOfMemoryError) {
                Log.e(TAG, "Memoria insuficiente al generar el collage", e)
                toast(getString(R.string.msg_compartir_error))
            } catch (e: Exception) {
                Log.e(TAG, "Error al compartir el collage", e)
                toast(getString(R.string.msg_compartir_error))
            } finally {
                btnCompartir.isEnabled = true
            }
        }
    }

    private fun saveBitmapToCache(bmp: Bitmap): Uri? {
        return try {
            val dir = File(cacheDir, "collages").apply { if (!exists()) mkdirs() }
            dir.listFiles()?.forEach { it.delete() } // evita acumular collages antiguos
            val file = File(dir, "collage_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo guardar el collage", e)
            null
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private companion object {
        const val TAG = "MainActivity"
        const val MAX_FOTOS = 20
        const val PREFIJO_FOTO = "foto_"
        const val SEEK_NEUTRO = 100 // posición del deslizador = brillo original
    }
}