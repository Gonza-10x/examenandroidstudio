package com.example.collageapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.collageapp.R
import com.example.collageapp.model.CollageImage

class CollageAdapter(
    private val onItemClick: (Long) -> Unit
) : RecyclerView.Adapter<CollageAdapter.VH>() {

    private var items: List<CollageImage> = emptyList()
    private var selectedId: Long? = null

    init {
        setHasStableIds(true)
    }

    fun submit(newItems: List<CollageImage>, newSelectedId: Long?) {
        items = newItems
        selectedId = newSelectedId
        notifyDataSetChanged()
    }

    override fun getItemId(position: Int): Long = items[position].id

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_collage, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.image.setImageBitmap(item.current)
        holder.image.contentDescription =
            holder.itemView.context.getString(R.string.desc_imagen_n, position + 1)
        holder.number.text = (position + 1).toString()
        holder.container.setBackgroundResource(
            if (item.id == selectedId) R.drawable.item_selected_bg
            else R.drawable.item_normal_bg
        )
        holder.itemView.setOnClickListener { onItemClick(item.id) }
    }

    override fun getItemCount(): Int = items.size

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val container: View = view.findViewById(R.id.containerItem)
        val image: ImageView = view.findViewById(R.id.imgItem)
        val number: TextView = view.findViewById(R.id.tvNumero)
    }
}
